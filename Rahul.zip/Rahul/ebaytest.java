package MavenPack;

import java.util.List;
import java.util.concurrent.TimeUnit;

import javax.swing.plaf.synth.SynthOptionPaneUI;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.events.EventFiringWebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.github.bonigarcia.wdm.WebDriverManager;

public class ebaytest {
	ChromeDriver driver;

	@BeforeTest
	public void beforetest() {
		// Invoking driver and getting into Website and maximized it and at last add
		// Implicit wait for each actions

		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();

		driver.get("https://www.ebay.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test
	public void testcase1() {
		// From drop down select cell phones & accessories category by using select class
		WebElement drop = driver.findElement(By.id("gh-cat"));
		Select sel = new Select(drop);
		sel.selectByVisibleText("Cell Phones & Accessories");
		
		// click on search button
		driver.findElement(By.xpath("//input[@value='Search']")).click();
		
		// click on cell phones &smart phones option from left column
		driver.findElement(By.linkText("Cell Phones & Smartphones")).click();
		
		// click on see all menu for a page
		driver.findElement(By.xpath("//button[@class='btn btn--small']")).click();
		
		// filter window will appear and there select 3 filters
		driver.findElement(By.xpath("//span[text()='Screen Size']")).click();
		driver.findElement(By.xpath("//div[contains(@id,'4.0')]")).click();
		
		// scroll down the filter window so that it reached to price and item location
		// menu
		EventFiringWebDriver ev = new EventFiringWebDriver(driver);
		ev.executeScript("document.querySelector('div[class=\"x-overlay__wrapper--left\"]').scrollTop=500");

		driver.findElement(By.xpath("//div[contains(@id,'price')]")).click();
		driver.findElement(By.xpath("//input[contains(@class,'-from')]")).sendKeys("100");
		driver.findElement(By.xpath("//input[contains(@class,'-to')]")).sendKeys("500");
		driver.findElement(By.xpath("//span[text()='Item Location']")).click();
		driver.findElement(By.xpath("//input[@value='US Only']")).click();
		driver.findElement(By.xpath("//button[text()='Apply']")).click();
		
		// wait for a "3 filters applied "tags , it conclude that result is loaded
		// completely
		WebDriverWait w = new WebDriverWait(driver, 15);
		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//span[contains(@class,'lyout')]")));
		
		//Verify the filter get applied by getting a text from header
		Assert.assertEquals(
				driver.findElement(By.xpath("//span[@class='b-pageheader__text']")).getText().contains("4.0 - 4.4"),
				true);

	}

	@Test
	public void testcase2() {

		// click on ebay logo to get ebay home page
		driver.findElement(By.cssSelector("a[id='gh-la']")).click();
		
		// In search bar type MacBook and select computer category
		driver.findElement(By.xpath("//input[@type='text']")).sendKeys("Macbook");
		WebElement drop = driver.findElement(By.id("gh-cat"));
		Select sel = new Select(drop);
		sel.selectByVisibleText("Computers/Tablets & Networking");
		driver.findElement(By.xpath("//input[@value='Search']")).click();
		
		// verify the page is loaded completely
		JavascriptExecutor js = (JavascriptExecutor) driver;
		Assert.assertEquals(js.executeScript("return document.readyState").toString().equals("complete"),true);
		
		// wait for result count element to appear
		WebDriverWait w = new WebDriverWait(driver, 15);
		w.until(ExpectedConditions.visibilityOfAllElementsLocatedBy(By.xpath("//h1[contains(@class,'count')]")));
		
		// Verify the first list contain MacBook into it
		Assert.assertEquals(
				driver.findElement(By.xpath("//div[@class='s-item__title']/span/span")).getText().contains("MacBook"),
				true);

	}

	@AfterTest
	public void close() {
		//to close a driver 
		driver.close();
	}

}
